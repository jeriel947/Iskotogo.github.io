<link rel="stylesheet" href="./CSS/access-denied.css">

<section>
    <div class="access-denied-container">
        <div class="image">
            <img src="images/messages/access-denied.svg" alt="">
        </div>
        <div class="text">
            <h2>
                You don't have access to this page
            </h2>
        </div>
    </div>
</section>